#!/bin/bash
java -jar $( dirname -- "$0"; )/my-app-1.0-SNAPSHOT.jar "$@"