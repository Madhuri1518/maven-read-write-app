#!/bin/bash
java -jar my-app-1.0-SNAPSHOT.jar "$@"